deno run --allow-read --allow-write index.ts ~/freedesign5_clean/src
