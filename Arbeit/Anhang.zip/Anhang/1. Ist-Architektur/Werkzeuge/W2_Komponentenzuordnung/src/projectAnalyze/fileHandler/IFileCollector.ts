export interface IFileCollector {
    collection: ReadonlyArray<string>
}