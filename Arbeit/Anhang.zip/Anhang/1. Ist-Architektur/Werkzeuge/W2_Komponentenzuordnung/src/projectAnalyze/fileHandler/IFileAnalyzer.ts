export interface IFileAnalyzer<T> {
  result: T[]
}
